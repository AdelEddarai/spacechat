import LoadingDialog from "@/components/ui/loading-dialog";

export default function LaodingChats() {
  return <LoadingDialog />;
}
