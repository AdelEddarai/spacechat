export const siteConfig = {
  name: "Chatterbox",
  description:
    "Discover the magic of seamless communication with Chatterbox - the ultimate chat app that brings your conversations to life! Connect with anyone and watch your words dance across the screen in real-time.",
  url: "https://chatterboxes.vercel.app",
};
