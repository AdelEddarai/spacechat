"use client";

import useMembersStatus from "@/hooks/useMembersStatus";

const ActiveStatus = () => {
  useMembersStatus();

  return null;
};

export default ActiveStatus;
