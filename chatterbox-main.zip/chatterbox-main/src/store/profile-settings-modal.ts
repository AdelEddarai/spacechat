import { atom } from "jotai";

export const profileModalAtom = atom(false);
