import { atom } from "jotai";

export const activeUsersAtom = atom<string[]>([]);
